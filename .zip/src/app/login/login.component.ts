import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServiceService } from './../Services/auth-service.service';
import { User, IUser } from './../Models/UsersModel'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent {
  title = 'Document Manager';
  User: User = new User(null);
  loading = false;

  constructor(private _AuthService: AuthServiceService, private router: Router) { }

  Login() {
    this._AuthService.userAuthentication(this.User).subscribe(
      (success: IUser) => {
        console.log(success);
        // this.router.navigateByUrl(this.returnUrl);
        if (success) {
          sessionStorage.setItem('iname', success.UserName);
          alert("Authenticated User");
          this.router.navigate(['home']);
        } else alert("Invalid User")
      }, error => {
        console.log(error);
      });
  }


}