export interface IUser {
    UserId: number,
    UserPassword?: string,
    UserName: string,
    UserEmail: string,
    UserContact: string,
}

export class User implements IUser {
    UserId: number;
    UserPassword?: string;
    UserName: string;
    UserEmail: string;
    UserContact: string;
    constructor(Data: IUser) {
        if (Data) {
            this.UserId = Data.UserId;
            this.UserPassword = Data.UserPassword;
            this.UserEmail = Data.UserEmail;
            this.UserContact = Data.UserContact;
            this.UserName = Data.UserName;
        }
    }
}