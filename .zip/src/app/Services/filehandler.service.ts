import { Injectable } from "@angular/core";
import { HttpClient,HttpHeaders } from "@angular/common/http";
import { ConfigService } from "./config.service";
import { map } from 'rxjs/operators';
import { promise } from "protractor";

@Injectable()
export class FileHandlerService{
    private actionURL:string;
    constructor(private http: HttpClient,private _configService:ConfigService){
        this.actionURL=this._configService.Config.ApiUrl;
    }

      uploadFile(_model){
          let headers = new HttpHeaders();
        headers.append('Content-Type', 'undefined');
      
        return this.http.post(this.actionURL+'/FileHandler/UploadFile',_model,{ headers: headers });
    }

    // getContainerList(){
    //     return this.http.get<any>(this.actionURL+'/filehandler/ContainerList').toPromise();
    // }

    // downloadInvoiceFile(_model){
    //     return this.http.post(this.actionURL+'/filehandler/DownloadInvoice',_model,{responseType: 'blob'}); 
    // }
}