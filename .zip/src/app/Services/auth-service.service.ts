import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ConfigService } from './config.service';
import { User ,IUser} from './../Models/UsersModel'


@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  ApiUrl: string;

  constructor(private http: HttpClient,private _config :ConfigService) { 
      this.ApiUrl = _config.Config.ApiUrl;

  }


 userAuthentication(Data: User) {
      return this.http.post<any>(`${this.ApiUrl}/UserDetails`, { UserID: Data.UserName, Pwd:Data.UserPassword });
    }

}
