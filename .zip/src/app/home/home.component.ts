import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { FileHandlerService } from "../Services/filehandler.service";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  providers: [FileHandlerService],
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  UserID: number = 0;
  fileToUpload: File = null;
  formData: FormData = null;
  public loading = false;
  data: string = sessionStorage.getItem('iname');

  constructor(private _FileHandlerService: FileHandlerService,
    private changeDetectorRef: ChangeDetectorRef) { }
  ngOnInit() { }



  file;
  filename;

  SelectFile(e) {
    for (var i = 0; i < e.target.files.length; i++) {
      this.file = e.target.files[i]
      this.filename = e.target.files[i].name
    }
    this.changeDetectorRef.detectChanges();
  }

  UploadFile() {
    // debugger;
    let formData: FormData = new FormData();
    formData.append("UserId", this.UserID.toString());
    // for (var i = 0; i < event.target.files.length; i++) {
    formData.append("fileUpload", this.file, this.filename);
    // }
    // this.formData.append("",);
    // this.loading = true;
    this._FileHandlerService.uploadFile(formData)
      .subscribe(
      success => {
        success ? alert('Upload successful.') : alert('Upload failed.');
        // this.modalService.dismissAll();
        this.loading = false;
        // this.alertType = 'success';

      },
      err => {
        this.loading = false;
        // this.alertType = 'danger';
        // this.showAlert('Server error while uploading file.');
      }
      );
  }

  // UploadFile()
  // {
  //   alert('working');
  // }

}
